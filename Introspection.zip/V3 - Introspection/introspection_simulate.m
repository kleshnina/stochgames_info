function [coopvec,Str,M]=introspection_simulate(q,uv1,beta,info,tmax);

% [coop,freq]=EvolProc(rv,pv1,pv2,s,nGen)
% rv=(rCC1,rCD1,rDC1,rDD1,rCC2,rCD2,rDC2,rDD2) ... transition probabilities 
% depending on previous action profile and state
% uv1=(uCC1,uCD1,uDC1,uDD1,uCC2,uCD2,uDC2,uDD2) ... Payoff vector (from the 
% perspective of player 1, depending on action profile and state
% s ... selection strength
% coop ... average cooperation rate, % pay ... average payoff
% s1 ... average frequency of being in State 1
% freq ... average abundance for each strategy

%tic

%% Setting up all objects
rv = [q(1), q(2), q(2), q(3), q(4), q(5), q(5), q(6)]; 

uv2=uv1; uv2(2:3)=uv1(3:-1:2); uv2(6:7)=uv1(7:-1:6); % Creating the payoff vector from the perspective of player 2
if info==0 % No information
    sdim=4; 
    nStr=2^sdim; Str=zeros(nStr,8); 
    for i=1:nStr
        str_i=sscanf(dec2bin(i-1,4), '%1d' )';
        Str(i,:)=[str_i,str_i]; 
    end
else % With information
    sdim=8; 
    nStr=2^sdim; Str=zeros(nStr,8); 
    for i=1:nStr
        str_i=sscanf(dec2bin(i-1,8), '%1d' )';
        Str(i,:)=str_i; 
    end
end


% Creating matrices that record the payoff (M), the cooperation rate (C)
% and the abundance of being in state 1 (S1) for each pair of strategies
M=zeros(nStr,nStr); C=M; S1=M; 
for i=1:nStr
    for j=i:nStr
        [pi1,pi2,cop1,cop2,s1]=payoff(Str(i,:),Str(j,:),rv,uv1,uv2);
        M(i,j)=pi1; M(j,i)=pi2; C(i,j)=cop1; C(j,i)=cop2;  S1(i,j)=s1;
    end
end

coopvec=zeros(1,tmax); 

p1=1; p2=1; %Player's initial strategy is ALLD
for t=1:tmax
    
    if rand(1)<1/2 % Player 1 updates
        p1new=randi(nStr); 
        pi1old=M(p1,p2); 
        pi1new=M(p1new,p2);
        rho = 1/(1+exp(-beta*(pi1new-pi1old))); 
        if rand(1)< rho
            p1=p1new;
        end
        
    else
        p2new=randi(nStr);
        pi2old=M(p2,p1); 
        pi2new=M(p2new,p1);
        rho = 1/(1+exp(-beta*(pi2new-pi2old))); 
        if rand(1)<rho
            p2=p2new;
        end
    end
    
    coopvec(t)=(C(p1,p2)+C(p2,p1))/2;
end
end


function [pi1,pi2,cop1,cop2,s1]=payoff(p,q,rv,piv1,piv2);
eps=10^(-2); p=p*(1-eps)+(1-p)*eps; q=q*(1-eps)+(1-q)*eps; 
M=[rv(1)*p(1)*q(1), rv(1)*p(1)*(1-q(1)), rv(1)*(1-p(1))*q(1), rv(1)*(1-p(1))*(1-q(1)), (1-rv(1))*p(5)*q(5), (1-rv(1))*p(5)*(1-q(5)), (1-rv(1))*(1-p(5))*q(5), (1-rv(1))*(1-p(5))*(1-q(5));
   rv(2)*p(2)*q(3), rv(2)*p(2)*(1-q(3)), rv(2)*(1-p(2))*q(3), rv(2)*(1-p(2))*(1-q(3)), (1-rv(2))*p(6)*q(7), (1-rv(2))*p(6)*(1-q(7)), (1-rv(2))*(1-p(6))*q(7), (1-rv(2))*(1-p(6))*(1-q(7));
   rv(3)*p(3)*q(2), rv(3)*p(3)*(1-q(2)), rv(3)*(1-p(3))*q(2), rv(3)*(1-p(3))*(1-q(2)), (1-rv(3))*p(7)*q(6), (1-rv(3))*p(7)*(1-q(6)), (1-rv(3))*(1-p(7))*q(6), (1-rv(3))*(1-p(7))*(1-q(6));
   rv(4)*p(4)*q(4), rv(4)*p(4)*(1-q(4)), rv(4)*(1-p(4))*q(4), rv(4)*(1-p(4))*(1-q(4)), (1-rv(4))*p(8)*q(8), (1-rv(4))*p(8)*(1-q(8)), (1-rv(4))*(1-p(8))*q(8), (1-rv(4))*(1-p(8))*(1-q(8));
   rv(5)*p(1)*q(1), rv(5)*p(1)*(1-q(1)), rv(5)*(1-p(1))*q(1), rv(5)*(1-p(1))*(1-q(1)), (1-rv(5))*p(5)*q(5), (1-rv(5))*p(5)*(1-q(5)), (1-rv(5))*(1-p(5))*q(5), (1-rv(5))*(1-p(5))*(1-q(5));
   rv(6)*p(2)*q(3), rv(6)*p(2)*(1-q(3)), rv(6)*(1-p(2))*q(3), rv(6)*(1-p(2))*(1-q(3)), (1-rv(6))*p(6)*q(7), (1-rv(6))*p(6)*(1-q(7)), (1-rv(6))*(1-p(6))*q(7), (1-rv(6))*(1-p(6))*(1-q(7));
   rv(7)*p(3)*q(2), rv(7)*p(3)*(1-q(2)), rv(7)*(1-p(3))*q(2), rv(7)*(1-p(3))*(1-q(2)), (1-rv(7))*p(7)*q(6), (1-rv(7))*p(7)*(1-q(6)), (1-rv(7))*(1-p(7))*q(6), (1-rv(7))*(1-p(7))*(1-q(6));
   rv(8)*p(4)*q(4), rv(8)*p(4)*(1-q(4)), rv(8)*(1-p(4))*q(4), rv(8)*(1-p(4))*(1-q(4)), (1-rv(8))*p(8)*q(8), (1-rv(8))*p(8)*(1-q(8)), (1-rv(8))*(1-p(8))*q(8), (1-rv(8))*(1-p(8))*(1-q(8))];
v=null(M'-eye(8)); v=v/sum(v);
pi1=piv1*v; pi2=piv2*v;
cop1=v(1)+v(2)+v(5)+v(6); cop2=v(1)+v(3)+v(5)+v(7);
s1=sum(v(1:4));
end
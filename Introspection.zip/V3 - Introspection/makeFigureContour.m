function makeFigureContour()

global fsA fsL fsH fname lw col ms 

%% Setting up the parameters
fsA=13; fsL=13; fsH=18; fname='Arial'; 
FigPos=[200 200 780 350];
le1=0.06; bo1=0.12; wi1=0.33; he1=wi1*FigPos(3)/FigPos(4);
le2=0.48; bo2=bo1; wi2=wi1; he2=he1;
le3=0.87; bo3=bo1; wi3=0.03; he3=he1;

lw=2; ms=6; 
col=[0 0.447 0.741;
    0.85 0.325 0.098;
    0.494 0.184 0.556;
    0.929 0.694 0.125;
    0.466 0.674 0.188];


figure('Position',FigPos); 

axPos1=[le1 bo1 wi1 he1]; 
title1={'Timeout game','{\bf q} = (1,0,0,1,1,1)'}; 
number=1;
makePanel(axPos1,title1,number); 

axPos2=[le2 bo2 wi2 he2]; 
title2={'Timeout game with conditional return','{\bf q} = (1,0,0,1,1,0)'}; 
number=2;
makePanel(axPos2,title2,number); 

axPos3=[le3 bo3 wi3 he3]; 
makeColorLegend(axPos3);

end


function makePanel(axPos,title,number)

global fsA fsL fsH fname lw col ms 

load('DataSim_Introspection.mat');

ax1=axes('Position',axPos,'FontName',fname,'FontSize',fsA,...
    'xTick',[1.3:0.35:2],'YTick',10.^(0:3),'YScale','log','TickLength',[0.02 0.02]); 
box(ax1,'on'); hold on
axis([1.25 2.05 10^0/1.5 10^3*1.5]);
if number == 1
   ylabel('Selection strength','FontSize',fsA,'FontName',fname)
end
xlabel('Benefit in State 1','FontSize',fsA,'FontName',fname)
lett= 'ab'; text(1.2,3*10^3,lett(number),'FontName',fname,'FontSize',fsH,'FontWeight','bold')
text(1.65,3*10^3,title,'FontName',fname,'FontSize',fsL,...
    'HorizontalAlignment','center');


eval(['DatFIG=coopFIG',num2str(number),';']);
eval(['DatNIG=coopNIG',num2str(number),';']);
V=DatFIG-DatNIG; 
nb1=length(b1vec); nbeta=length(betavec);
fx=(b1vec(2)-b1vec(1))*0.51; fy=0.11; %sPoss(2)/sPoss(1);
for ib1=1:nb1
    for ibeta=1:nbeta
        cl=getcolor(V(ib1,ibeta));
        fill(b1vec(ib1)+[-fx fx fx -fx],betavec(ibeta)*[1-fy 1-fy 1+fy 1+fy],cl,...
            'EdgeColor',cl); 
    end
end

end

function makeColorLegend(AxPos); 
global fsA fsL fsH fname lw col ms 
ax3=axes('Position',AxPos,'FontName',fname,...
    'FontSize',fsA,'yTick',-1:0.5:1,'xTick',[],'yTickLabel',{'-1.0','-0.5','0.0','0.5','1.0'}); 
box(ax3,'on'); hold on
axis([-1 1 -1.1 1.1]); 
%text(3,0,'Cooperation premium for no information','FontName',fname,...
%    'FontSize',fsA,'HorizontalAlignment','center','Rotation',90);

for x=-1:0.05:1
    fill(0.6*[-1 -1 1 1],x+0.026*[-1 1 1 -1],getcolor(x),'LineStyle','none');
end

text(2,0,'Value of information','FontName',fname,'FontSize',fsA,...
    'Rotation',90,'HorizontalAlignment','center'); 
text(4,1,{'Benefit of','information'},'FontName',fname,'FontSize',fsA,...
    'HorizontalAlignment','center'); 
text(4,-1,{'Benefit of','ignorance'},'FontName',fname,'FontSize',fsA,...
    'HorizontalAlignment','center'); 

end


function cl=getcolor(B);

global fsA fsL fsH fname lw le1 bo1 wi1 he1 dx1 dy1 dx2 bo2 he2 wi2 col ms

if B>0; 
    cl=col(1,:); B=B; 
else
    cl=col(2,:); B=-B; 
end

la=B; 
cl=la*cl+(1-la)*[1 1 1]; 
end
function makeDataContour();

tic
b2=1.3; c=1; tmax=10^7; % General parameters
b1vec=1.3:0.025:2; % Possible values of b1
betavec=10.^(0:.1:3); % Possible values of beta
nb=length(b1vec), nbeta=length(betavec) 
q1=[1 0 0 1 1 1]; % Timeout game
q2=[1 0 0 1 1 0]; % Timeout game with conditional return
data=['b2=',num2str(b2),'; c1=',num2str(c),'; tmax=',num2str(tmax)];

coopFIG1=zeros(nb,nbeta); coopNIG1=coopFIG1; % Initializing the output
coopFIG2=coopFIG1; coopNIG2=coopFIG1; 

tic

for ib=1:nb
    b1=b1vec(ib)
    pv1=[b1-c -c b1 0 b2-c -c b2 0]; % Payoff vector
    parfor ibeta=1:nbeta
        beta=betavec(ibeta); 
        
        info=0; [coopvec,Str,M]=introspection_simulate(q1,pv1,beta,info,tmax);
        coopNIG1(ib,ibeta)=mean(coopvec); 
        
        info=1; [coopvec,Str,M]=introspection_simulate(q1,pv1,beta,info,tmax);
        coopFIG1(ib,ibeta)=mean(coopvec);
        
        info=0; [coopvec,Str,M]=introspection_simulate(q2,pv1,beta,info,tmax);
        coopNIG2(ib,ibeta)=mean(coopvec); 
        
        info=1; [coopvec,Str,M]=introspection_simulate(q2,pv1,beta,info,tmax);
        coopFIG2(ib,ibeta)=mean(coopvec);
         

    end
end
 
sim_time=toc;
filename='DataSim_Introspection.mat'; 
save(filename,'coopNIG1','coopFIG1','coopNIG2','coopFIG2','b1vec','betavec','data','sim_time'); 
end